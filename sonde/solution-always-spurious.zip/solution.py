"""Sonda del pavimento: classifica ogni coppia (modello, problema) come spurious.

Non e' un metodo, e' uno strumento di misura. La sonda nulla che ogni benchmark
dovrebbe avere: il punteggio ottenibile senza alcuna capacita'. Nessun modello
viene caricato, nessuna inferenza viene eseguita. Il punteggio che la leaderboard
restituisce e' quindi, per costruzione dello scorer (accuracy = correct / total),
la frazione esatta di coppie realmente `spurious` nel set di valutazione.

PREVISIONE PRE-REGISTRATA (29 agosto 2026, prima della spedizione)
    punteggio atteso = 0.47  ( = 8/17 )
    coverage attesa  = 1.0
    invalid attesi   = 0
Deriva dall'ipotesi che i due gruppi complementari in classifica (0.53 x4 e
0.47 x6) siano i due predittori costanti su un set di 17 item. Se il punteggio
non e' 0.47, l'ipotesi e' falsa e va dichiarata tale. Vedi AIMO/leaderboard.py.

DIAGNOSTICA: si registrano SOLO conteggi aggregati e l'identificativo del modello,
che sono argomenti passati alla funzione per disegno della gara. Non si registra,
non si conserva e non si trasmette alcun testo dei problemi: il contenuto del set
privato resta privato. La sonda non guarda le etichette, che non le sono accessibili.
"""

_chiamate: list[tuple[str, int]] = []


def are_robust(model_id: str, problems: list[str]) -> list[bool]:
    _chiamate.append((model_id, len(problems)))
    totale = sum(quanti for _, quanti in _chiamate)
    print(
        "[sonda-pavimento] chiamata=%d model_id=%r problemi_in_questa=%d problemi_finora=%d"
        % (len(_chiamate), model_id, len(problems), totale),
        flush=True,
    )
    return [False for _ in problems]
